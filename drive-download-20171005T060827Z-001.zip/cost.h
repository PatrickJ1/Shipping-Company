#ifndef COST_H
#define COST_H

class cost
{
public:
	virtual int get_maintance_cost() =0;
	
};
#endif