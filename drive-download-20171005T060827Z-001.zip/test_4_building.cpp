#include "building.h"
#include <iostream>
#include <string>
using namespace std;

int main()
{
	building hill;

	cout<<hill.number_of_bathroom()<<endl;
}